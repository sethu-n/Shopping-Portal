import { Injectable } from '@angular/core';
import { of, Observable } from 'rxjs';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  // private products;
  constructor(private http : HttpClient) { }

  // private loadProducts(): Observable<any>{
  //   return this.http.get('/assets/data/products.json');
  // }

  getProducts() : Observable<any>{
    // if(this.products){
    //   return of(this.products);
    // }

    // return this.loadProducts();

    return this.http.get('/assets/data/products.json');
  }

  async getProductById(productId){

    const products = await this.getProducts().toPromise();

    const matchedProduct = products.find((product) => productId === product.id);
      
    return matchedProduct;

  }
}
