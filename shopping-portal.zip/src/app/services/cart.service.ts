import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  private cart = [];

  constructor() { }

  getCartList(){
    return this.cart;
  }

  addItemToCart(item){
    const matchedItemIndex = this.cart.findIndex((cartItem) => cartItem['id'] === item['id']);

    if(matchedItemIndex >= 0){
      return this.updateCartItemByIndex(matchedItemIndex,item);
    }

    return this.cart.push(item);
  }

  updateCartItem(itemId ,item){
    const matchedItemIndex = this.cart.findIndex((cartItem) => cartItem['id'] === itemId);

    if(matchedItemIndex < 0){
      return;
    }

    return this.updateCartItemByIndex(matchedItemIndex,item);
  }

  updateCartItemByIndex(itemIndex,item){
    if(item.quantity === 0){
      return this.removeItemFromCart(itemIndex);
    }

    this.cart[itemIndex] = {...this.cart[itemIndex],...item};
    return this.cart; 
  }

  removeItemFromCart(itemIndex: number){
    this.cart.splice(itemIndex,1);

    return this.cart;
  }

  getItemFromCart(itemId: string){
    return this.cart.find((item)=> item['id'] === itemId);
  }

  // getItemsFromCart(itemIds : string[]){
  //   return this.cart.filter((item) => itemIds.indexOf(item.id) >= 0);
  // }
}
