import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router , ActivatedRoute } from '@angular/router';
import { ProductsService } from './../../services/products.service';
import { CartService } from './../../services/cart.service';
import { FormControl, Validators, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.scss']
})
export class ProductDetailsComponent implements OnInit, OnDestroy {

  productId:string ;
  productDetails;
  countAdded = new FormControl(0);
  addedToCart = false;
  countSubscriber;

  constructor(private activatedRoute:ActivatedRoute ,
              private router: Router ,
              private product : ProductsService,
              private cart: CartService) { }

  ngOnInit(): void {
    this.productId = this.activatedRoute.snapshot.paramMap.get('productId');

    if(this.productId){
      this.loadProductDetails(this.productId)
    }

    this.setupListener();
  }

  loadProductDetails(productId){

    this.product.getProductById(productId).then((data)=> {
      this.productDetails = data;


      const productInCart = this.cart.getItemFromCart(this.productDetails.id);

      this.countAdded.setValidators([
        Validators.min(0),
        Validators.max(this.productDetails.availableStock)
      ]);

      if(productInCart){
        this.countAdded.setValue(productInCart.quantity);
        this.addedToCart = true;
      }
      
    });
  }

  setupListener(){
    this.countSubscriber = this.countAdded.valueChanges.subscribe((value)=>{
      if(this.addedToCart && this.countAdded.valid){
        this.cart.updateCartItem(this.productId , { quantity : value});
        if(value === 0){
          this.addedToCart = false;
        }
      }
    })
  }

  addToCart(){
    const cartData = {
      id : this.productId,
      quantity : this.countAdded.value,
      productDetails : this.productDetails
    }

    this.cart.addItemToCart(cartData);
    this.addedToCart = true;
  }

  navigateToShop(){
    this.router.navigate(['products']);
  }
  
  ngOnDestroy(){
    this.countSubscriber.unsubscribe();
  }
}
