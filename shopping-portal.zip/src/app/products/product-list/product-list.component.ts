import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { ProductsService } from './../../services/products.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {

  constructor(private router: Router, private productData: ProductsService) { }

  products;
  noOfItemsToShow = 8;

  ngOnInit(): void {
    this.loadProducts();
  }

  loadProducts(){
    this.productData.getProducts().subscribe((products)=>{
      this.products = products;
    });
  }

  loadMore(){
    this.noOfItemsToShow += 8;
  }
  navigateToProduct(product){
    this.router.navigate(['products', product.id]);
  }
}
