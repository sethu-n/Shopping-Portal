import { Component, OnInit } from '@angular/core';
import { CartService } from './../../services/cart.service';
import { Router } from '@angular/router';
import { FormArray, FormBuilder,FormGroup} from '@angular/forms';
import {debounceTime } from 'rxjs/operators';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {

  cartList:any [];
  shippingCost = 50;
  cartForm = new FormGroup({
    items : new FormArray([])
  });
  cartTotal = 0;

  constructor(private cart: CartService, private router: Router, private fb : FormBuilder) { }

  ngOnInit(): void {
    this.loadCart();
    this.setUpListeners();
  }

  loadCart(){
    this.cartList = this.cart.getCartList();

    if(this.cartList.length){
      this.buildCartForm();
    }
  }

  get items(){
    return this.cartForm.get('items') as FormArray;
  }

  buildCartForm(){

    this.cartList.forEach((item)=>{
      const itemGroup = this.fb.group({
        id : item.id,
        productName : item.productDetails.name,
        price : item.productDetails.price,
        quantity : item.quantity,
        total : item.quantity * item.productDetails.price
      });

      this.items.push(itemGroup);
    })

    this.calculateCartTotal(this.items.getRawValue());

  }

  setUpListeners(){
    this.items.valueChanges.pipe(debounceTime(100)).subscribe((value)=>{
      this.calculateCartTotal(value);
    })
  }

  updateTotalForItem(quantity ,index){
    const price = this.items.at(index).get('price').value;

    this.items.at(index).patchValue({
      total : price * quantity
    }, {
     onlySelf : true 
    });

  }

  handleQuantityChange(event, index){

    const quantity = Number(event.target.value);
    
    if(quantity === 0){
      return this.removeItemFromCart(index);
    }

    this.updateTotalForItem(quantity,index);

    return this.cart.updateCartItem(this.cartList[index]['id'] , { quantity});
  }

  removeItemFromCart(index){
    this.items.removeAt(index);
    this.cartList = this.cart.removeItemFromCart(index);
  }

  calculateCartTotal(list){
    console.log(list);
    this.cartTotal = list.reduce((sum,item) => sum+= (item.price * item.quantity),0);
  }

  navigateToShop(){
    this.router.navigate(['products']);
  }
}
